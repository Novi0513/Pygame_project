import pygame
from classes import Mainscreen, Intro, Gamewindow


def terminate():
   pygame.quit()


def start_screen():
    intro_text = ["ЗАСТАВКА", "",
    "Правила игры",
    "Нажмите любую кнопку"]
    clock_st = pygame.time.Clock()
    screen.fill((0, 0, 0))
    font = pygame.font.Font(None, 30)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line,
                                      1,
                                      pygame.Color('white'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered,
                    intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                    terminate()
            elif event.type == pygame.KEYDOWN:
                return
        pygame.display.flip()
        clock_st.tick(50)



if __name__ == '__main__':
   pygame.init()
   # размеры окна:
   size = width, height = 800, 600
   screen = pygame.display.set_mode(size)
   screen.fill((50, 50, 50))
   screen1 = pygame.display.set_mode(size)
   start_screen()
   main_screen = Mainscreen(screen1)
   clock = pygame.time.Clock()
   # смена (отрисовка) кадра:
   pygame.display.flip()
   running = True
   end = 0
   ex = 0
   while running:
       for event in pygame.event.get():
           if event.type == pygame.QUIT:
               ex = 1
               end = 1
           elif event.type == pygame.KEYDOWN:
               if event.unicode == '':
                   ex = 1
                   end = 1
               else:
                   print(event.unicode)
           elif event.type == pygame.MOUSEBUTTONUP:
                   if event.pos[0] >= main_screen.start_button()[0] \
                   and event.pos[0] <= main_screen.start_button()[2] \
                   and event.pos[1] >= main_screen.start_button()[1] \
                   and event.pos[1] <= main_screen.start_button()[3]:
                       print('ok')
                       end = 1
       pygame.display.flip()
       if end == 1:
           running = False
   clock.tick(50)
   if ex == 1:
       pygame.quit()
   if end == 1:
       intro = Intro(screen1, True)

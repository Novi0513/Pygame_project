import os
import sys
import pygame
import sqlite3
from random import randint


def load_image(name):
    fullname = os.path.join('Images/',
                            name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image_func = pygame.image.load(fullname)
    return image_func

class Mainscreen:
    def __init__(self, mainscreen):
        self.screen = mainscreen
        self.screen.fill((50, 50, 50))
        self.sprites = pygame.sprite.Group()
        self.image = load_image("Forest.jpg")
        self.sprite = pygame.sprite.Sprite()
        self.image1 = pygame.transform.scale(self.image,
                                       (800, 600))
        self.sprite.image = self.image1
        self.sprite.rect = self.sprite.image.get_rect()
        self.sprites.add(self.sprite)
        self.sprites.draw(self.screen)
        self.sprite.rect.x = 0
        self.sprite.rect.y = 0
        self.font = pygame.font.Font(None, 100)
        self.text = self.font.render("Magic Forest",
                                     True,
                                     (100, 100, 100))
        self.text_x = 800 // 2 - self.text.get_width() // 2
        self.text_y = 600 // 4 - self.text.get_height() // 2
        self.screen.blit(self.text,
                        (self.text_x,
                         self.text_y))
        self.text1 = self.font.render("Новая игра",
                                      True,
                                      (240, 190, 0))
        self.text1_x = 800 // 2 - self.text1.get_width() // 2
        self.text1_y = 600 // 2 - self.text1.get_height() // 2
        self.text1_w = self.text1.get_width()
        self.text1_h = self.text1.get_height()
        self.screen.blit(self.text1,
                         (self.text1_x,
                          self.text1_y))
        pygame.draw.rect(self.screen,
                         (200, 200, 0),
                         (self.text1_x - 10,
                               self.text1_y - 10,
                               self.text1_w + 20,
                               self.text1_h + 20), 10)

    def start_button(self):
        return (self.text1_x - 10,
                self.text1_y - 10,
                self.text1_x + self.text1_w + 20,
                self.text1_y + self.text1_h + 20)

class Intro:
    def __init__(self, mainscreen, run):
        self.screen = mainscreen
        self.screen.fill((0, 0, 0))
        self.sprites = pygame.sprite.Group()
        self.image = load_image("Night.jpg")
        self.sprite = pygame.sprite.Sprite()
        self.image1 = pygame.transform.scale(self.image, (800, 600))
        self.sprite.image = self.image1
        self.sprite.rect = self.sprite.image.get_rect()
        self.sprites.add(self.sprite)
        self.sprites.draw(self.screen)
        self.sprite.rect.x = 0
        self.sprite.rect.y = 0
        self.clock = pygame.time.Clock()
        self.running = run
        self.text_coord = 50
        self.font = pygame.font.Font(None, 30)
        self.intro_text = ["Давным давно...", "",
                      "В тёмном волшебном лесу был потерян крайне мощный артефакт.",
                      "Говорят, что она способен подарить владельцу божественную силу,",
                      "и даже вдохнуть жизнь в мертвеца.",
                      "Многие герои, наёмники и волшебники отправились в лес, но ни",
                      "ещё не вернулся живым. Нажмите любую кнопку, кроме ESC"]
        for line in self.intro_text:
            self.string_rendered = self.font.render(line,
                                                    1,
                                                    pygame.Color('grey'))
            self.intro_rect = self.string_rendered.get_rect()
            self.text_coord += 10
            self.intro_rect.top = self.text_coord
            self.intro_rect.x = 100
            self.text_coord += self.intro_rect.height
            self.screen.blit(self.string_rendered,
                             self.intro_rect)
        pygame.display.flip()
        end = 0
        ex = 0
        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    ex = 1
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    if event.unicode == '':
                        ex = 1
                        self.running = False
                    else:
                        end = 1
                        self.running = False
        self.clock.tick(50)
        if ex == 1:
            pygame.quit()
        if end == 1:
            self.main = Gamewindow(self.screen, 100, 0, 'battle')


class Gamewindow:
    def __init__(self, mainscreen, health, inventory, event_type='No type'):
        self.char = Character()
        self.con = sqlite3.connect("PyGame.sqlite")
        self.cur = self.con.cursor()
        self.screen = mainscreen
        self.health = health
        self.btl = f''
        self.inventory = inventory
        self.event = []
        self.event_type = event_type
        self.event_text = []
        self.change_event(self.event_type)
        self.get_event_text()
        self.screen.fill((0, 0, 0))
        self.sprites = pygame.sprite.Group()
        self.image = load_image("Fon.jpg")
        self.sprite = pygame.sprite.Sprite()
        self.image1 = pygame.transform.scale(self.image,
                                             (800, 600))
        self.sprite.image = self.image1
        self.sprite.rect = self.sprite.image.get_rect()
        self.sprites.add(self.sprite)
        self.sprites.draw(self.screen)
        self.sprite.rect.x = 0
        self.sprite.rect.y = 0
        self.text_coord = 75
        self.clock = pygame.time.Clock()
        self.font = pygame.font.Font(None, 25)
        self.font1 = pygame.font.Font(None, 20)
        self.running = True
        pygame.display.flip()
        end = 0
        ex = 0
        while self.running:
            pygame.draw.rect(self.screen,
                       (35, 77, 61),
                        (50,
                         50,
                         700,
                         500))
            for line in self.event_text:
                self.string_rendered = self.font.render(line,
                                                        1,
                                                        pygame.Color('yellow'))
                self.intro_rect = self.string_rendered.get_rect()
                self.intro_rect.top = self.text_coord
                self.intro_rect.x = 100
                self.text_coord += self.intro_rect.height
                self.screen.blit(self.string_rendered,
                                 self.intro_rect)
            self.text_coord = 75
            self.first_button_pos = self.first_button()
            self.second_button_pos = self.second_button()
            self.string_rendered1 = self.font1.render(self.btl,
                                                    1,
                                                    pygame.Color('yellow'))
            self.screen.blit(self.string_rendered1,
                             (100,
                              200))
            self.string_rendered2 = self.font.render("HP" + str(self.char.get_health()) + ' Lv ' + str(self.char.get_level()),
                                                      1,
                                                      pygame.Color('yellow'))
            self.screen.blit(self.string_rendered2,
                             (100,
                              500))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    ex = 1
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    if event.unicode == '':
                        ex = 1
                        self.running = False
                elif event.type == pygame.MOUSEBUTTONUP:

                    if event.pos[0] >= self.first_button_pos [0] \
                            and event.pos[0] <= self.first_button_pos[2] +  self.first_button_pos [0]\
                            and event.pos[1] >= self.first_button_pos[1]  \
                            and event.pos[1] <= self.first_button_pos[3] + self.first_button_pos[1]:
                        if self.event_type == 'battle':
                           s = self.battle_ev()
                           if s == 1:
                               x = randint(0, 1)
                               if x == 0:
                                   self.change_event('battle')
                                   self.get_event_text()
                                   self.first_button_pos = self.first_button()
                                   self.second_button_pos = self.second_button()
                                   self.btl = f''
                               else:
                                   self.change_event('treasure')
                                   self.get_event_text()
                                   self.first_button_pos = self.first_button()
                                   self.second_button_pos = self.second_button()
                                   self.btl = f''
                        elif self.event_type == 'treasure':
                            self.char.get_inventory().add(self.item[0][2])
                            x = randint(0, 1)
                            if x == 0:
                                self.change_event('battle')
                                self.get_event_text()
                                self.first_button_pos = self.first_button()
                                self.second_button_pos = self.second_button()
                                self.btl = f''
                            else:
                                self.change_event('treasure')
                                self.get_event_text()
                                self.first_button_pos = self.first_button()
                                self.second_button_pos = self.second_button()
                                self.btl = f''
                    elif event.pos[0] >= self.second_button_pos[0] \
                            and event.pos[0] <= self.second_button_pos[2] + self.second_button_pos[0] \
                            and event.pos[1] >= self.second_button_pos[1] \
                            and event.pos[1] <= self.second_button_pos[3] + self.second_button_pos[1]:
                        if self.event_type == 'battle':
                            y = randint(0, 1)
                            if y == 1:
                                x = randint(0, 1)
                                if x == 0:
                                    self.change_event('battle')
                                    self.get_event_text()
                                    self.first_button_pos = self.first_button()
                                    self.second_button_pos = self.second_button()
                                    self.btl = f''
                                else:
                                    self.change_event('treasure')
                                    self.get_event_text()
                                    self.first_button_pos = self.first_button()
                                    self.second_button_pos = self.second_button()
                                    self.btl = f''
                            else:
                                self.char.damaged(self.enemy_d)
                                self.btl = 'Противник наносит вам удар. '
                        elif self.event_type == 'treasure':
                            x = randint(0, 1)
                            if x == 0:
                                self.change_event('battle')
                                self.get_event_text()
                                self.first_button_pos = self.first_button()
                                self.second_button_pos = self.second_button()
                                self.btl = f''
                            else:
                                self.change_event('treasure')
                                self.get_event_text()
                                self.first_button_pos = self.first_button()
                                self.second_button_pos = self.second_button()
                                self.btl = f''
                        elif self.event_type == 'death':
                            end = 1
            pygame.display.flip()
            if end == 1:
                self.running = False
        if ex == 1:
            pygame.quit()
        elif end == 1:
            self.endw = Finalwindow(self.screen, self.char)
        self.clock.tick(50)


    def change_event(self, event_type):
        result = list(self.cur.execute("""SELECT * FROM Events
                                WHERE event_type=(
            SELECT id FROM Event_types
                WHERE event_type = ?)""",
                (event_type,)).fetchall())
        n = randint(0, len(result) - 1)
        self.event = result[n]
        self.event_type = event_type

    def get_event_text(self):
        if self.event_type == 'battle':
            self.enemy = self.cur.execute("""SELECT * FROM Items
                                WHERE id = ?""",
                (self.event[2],)).fetchall()
            self.enemy_h = int(self.enemy[0][4])
            self.enemy_d = int(self.enemy[0][3])
            self.event_text = ["Вы видите враждебное существо",
                               f"Это {self.enemy[0][2]}",
                               f"У него {self.enemy_h} здоровья и",
                               f"обычно он наносит {self.enemy_d} урона"]
        elif self.event_type == 'treasure':
            self.item = self.cur.execute("""SELECT * FROM Items
                                            WHERE id = ?""",
                                          (self.event[2],)).fetchall()
            x = randint(0, 2)
            if x == 0:
               self.event_text = ["Вы видете опустевший лагерь приключенцев, ",
                                  "отправившихся в волшебный лес",
                                  "Вы с опаской проходите в него, как что-то неожиданно бьётся о вашу ногу",
                                  f"Похоже это {self.item[0][2]}"]
            elif x == 1:
                self.event_text = ["На опушке у одиноко стоящего дерева вы видите истлевшее тело рыцаря",
                                   "У его ног что-то блестит в бледных лучах солнца, с трудом пробивающихся",
                                   "сквозь тёмные кроны мрачных деревьев",
                                   f"Похоже это {self.item[0][2]}"]
            else:
                self.event_text = ["Посреди дороги вы видите обожённый след на земле",
                                   "Воздух вокруг причудливо искажается и переливается ",
                                   "разными цветами. Посреди этой картины вы видете предмет",
                                   f"Похоже это {self.item[0][2]}"]
        elif self.event_type == 'death':
            self.event_text = ["Похоже вы нашли свой конец в этом проклятом месте",
                               "Вы станете одной из тех страшных историй о людях,",
                               "Которых поглотил лес"]



    def first_button(self):
        self.text1_x = 400
        self.text1_y = 500
        if self.event_type == 'battle':
            self.text1 = self.font.render("Атаковать",
                                          True,
                                          pygame.Color('yellow'))
        elif self.event_type == 'treasure':
            self.text1 = self.font.render("Подобрать",
                                          True,
                                          pygame.Color('yellow'))
        elif self.event_type == 'death':
            self.text1 = self.font.render("",
                                          True,
                                          pygame.Color('yellow'))
        self.text1_w = self.text1.get_width()
        self.text1_h = self.text1.get_height()
        pygame.draw.rect(self.screen,
                         (100, 100, 100),
                         (400 - 10,
                          500 - 10,
                          self.text1_w + 20,
                          self.text1_h + 20))
        self.screen.blit(self.text1,
                         (self.text1_x,
                          self.text1_y))
        return (400 - 10,
                500 - 10,
                self.text1_w + 20,
                self.text1_h + 20)


    def second_button(self):
        self.text2_x = 600
        self.text2_y = 500
        if self.event_type == 'battle':
            self.text2 = self.font.render("Отступить",
                                          True,
                                          pygame.Color('yellow'))
        elif self.event_type == 'treasure':
            self.text2 = self.font.render("Уйти",
                                          True,
                                          pygame.Color('yellow'))
        elif self.event_type == 'death':
            self.text2 = self.font.render("Конец?",
                                          True,
                                          pygame.Color('yellow'))
        self.text2_w = self.text2.get_width()
        self.text2_h = self.text2.get_height()
        pygame.draw.rect(self.screen,
                         (100, 100, 100),
                         (600 - 10,
                          500 - 10,
                          self.text2_w + 20,
                          self.text2_h + 20))
        self.screen.blit(self.text2,
                         (self.text2_x,
                          self.text2_y))
        return (600 - 10,
                500 - 10,
                self.text2_w + 20,
                self.text2_h + 20)


    def battle_ev(self):
        if self.enemy_h > 0 and self.char.get_health() > 0:
            x = randint(0, 1)
            y = randint(0, 1)
            self.btl = f''
            if x == 1:
                self.enemy_h = self.enemy_h - 5
                self.btl += 'Вы ноносите противнику удар. '
            else:
                self.btl += 'Промах. '
            if y == 1:
                self.char.damaged(self.enemy_d)
                self.btl += 'Противник наносит вам удар. '
            self.btl += f'У противника осталось {self.enemy_h} здоровья'
            if self.char.get_health() == 0:
                self.btl = ''
                self.battle_ev()
            return 0
        elif self.char.get_health() <= 0:
            self.change_event('death')
            self.get_event_text()
            return 2
        else:
            self.char.change_level()
            return 1



    def change_health(self, health):
        self.health = health

    def get_health(self):
        return self.health

    def get_event_type(self):
        return self.event_type


class Character:
    def __init__(self):
        self.health = 100
        self.inventory = Inventory()
        self.defense = 0
        self.level = 1
        self.attack = 5

    def get_health(self):
        return self.health

    def damaged(self, strike):
        self.health = int(self.health  - strike)
        if self.health <= 0:
            self.health = 0
            return False
        else:
            return True

    def attack(self):
        return self.attack

    def healed(self, heal):
        self.health += heal
        if self.health > 100:
            self.health = 100

    def get_level(self):
        return self.level

    def change_level(self):
        self.level += 1

    def get_inventory(self):
        return self.inventory


class Finalwindow:
    def __init__(self, mainscreen, char):
        self.char = char
        self.screen = mainscreen
        self.text = [f"Ваш уровень {self.char.get_level()}",
                     "Вы собрали следующие предметы:",
                     f"{self.char.get_level()}",
                     "Для выхода нажмите Esc"]
        self.font1 = pygame.font.Font(None, 30)
        self.font = pygame.font.Font(None, 25)
        self.bigtext = self.font1.render("Спасибо за игру!",
                                        1,
                                        pygame.Color('yellow'))
        self.running = True
        ex = 0
        while self.running:
            self.screen.fill((20, 20, 20))
            self.text_coord = 300
            self.screen.blit(self.bigtext,
                             (100, 100))
            for line in self.text:
                self.string_rendered = self.font.render(line,
                                                        1,
                                                        pygame.Color('yellow'))
                self.intro_rect = self.string_rendered.get_rect()
                self.intro_rect.top = self.text_coord
                self.intro_rect.x = 100
                self.text_coord += self.intro_rect.height
                self.screen.blit(self.string_rendered,
                                 self.intro_rect)
            for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        ex = 1
                        self.running = False
                    elif event.type == pygame.KEYDOWN:
                        if event.unicode == '':
                            ex = 1
                            self.running = False
                        else:
                            pass
            pygame.display.flip()
        if ex == 1:
            pygame.quit()



class Inventory:
    def __init__(self):
        self.inventory = {}

    def get_inventory(self):
        return self.inventory

    def add(self, item):
        if item in self.inventory:
            self.inventory[item] += 1
        else:
            self.inventory[item] = 1

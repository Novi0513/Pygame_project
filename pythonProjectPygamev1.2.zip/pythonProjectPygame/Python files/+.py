import pygame
from random import randint


class Board:
    def __init__(self, width, height):
        screen.fill((0, 0, 0))
        self.width = width
        self.height = height
        self.board = [[0] * width for _ in range(height)]
        self.left = 10
        self.top = 10
        self.cell_size = 30
        for i in range(self.height):
            for j in range(self.width):
                self.board[i][j] = randint(0, 1)
                if self.board[i][j] == 0:
                    pygame.draw.circle(screen, (0, 0, 255), (self.left + (j + 0.5) * self.cell_size,
                                                             self.left + (i + 0.5) * self.cell_size),
                                       self.cell_size // 2 - 2)
                else:
                    pygame.draw.circle(screen, (255, 0, 0), (self.left + (j + 0.5) * self.cell_size,
                                                             self.left + (i + 0.5) * self.cell_size),
                                       self.cell_size // 2 - 2)

    def set_view(self, left, top, cell_size):
        self.left = left
        self.top = top
        self.cell_size = cell_size

    def render(self, screen):
        for i in range(self.height + 1):
            for j in range(self.width + 1):
                pygame.draw.rect(screen, (255, 255, 255), (self.left,
                                                           self.top, j * self.cell_size, i * self.cell_size), 1)

    def get_cell(self, mouse_pos):
        if mouse_pos[0] >= self.left:
            if mouse_pos[0] <= self.cell_size * self.width + self.left:
                if mouse_pos[1] >= self.top:
                    if mouse_pos[1] <= self.cell_size * self.height + self.top:
                        return ((mouse_pos[0] - self.left) // self.cell_size,
                                (mouse_pos[1] - self.top) // self.cell_size)
                    else:
                        return None
                else:
                    return None
            else:
                return None
        else:
            return None

    def on_click(self, cell_coords, screen):
        if cell_coords is not None:
            for i in range(self.width):
                if self.board[cell_coords[1]][cell_coords[0]] == 1:
                    pygame.draw.circle(screen, (255, 0, 0), (self.left + (i + 0.5) * self.cell_size,
                                                             self.top + (cell_coords[1] + 0.5) * self.cell_size),
                                       self.cell_size // 2 - 2)
                    self.board[cell_coords[1]][i] = 1
                else:
                    pygame.draw.circle(screen, (0, 0, 255), (self.left + (i + 0.5) * self.cell_size,
                                                             self.top + (cell_coords[1] + 0.5) * self.cell_size),
                                       self.cell_size // 2 - 2)
                    self.board[cell_coords[1]][i] = 0
            for j in range(self.height):
                if cell_coords[1] != j:
                    if self.board[cell_coords[1]][cell_coords[0]] == 1:
                        pygame.draw.circle(screen, (255, 0, 0), (self.left + (cell_coords[0] + 0.5) * self.cell_size,
                                                                 self.top + (j + 0.5) * self.cell_size),
                                           self.cell_size // 2 - 2)
                        self.board[j][cell_coords[0]] = 1
                    else:
                        pygame.draw.circle(screen, (0, 0, 255), (self.left + (cell_coords[0] + 0.5) * self.cell_size,
                                                                 self.top + (j + 0.5) * self.cell_size),
                                           self.cell_size // 2 - 2)
                        self.board[j][cell_coords[0]] = 0

    def get_click(self, mouse_pos, screen):
        cell = self.get_cell(mouse_pos)
        self.on_click(cell, screen)


if __name__ == '__main__':
    N = int(input())
    pygame.init()
    size = width, height = 800, 600
    screen = pygame.display.set_mode(size)
    board = Board(N, N)
    running = True
    pygame.display.set_caption('Never Fade Away')
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                board.get_click(event.pos, screen)
        board.render(screen)
        pygame.display.flip()